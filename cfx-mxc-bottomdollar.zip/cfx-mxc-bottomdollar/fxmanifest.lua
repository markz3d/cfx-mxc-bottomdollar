fx_version "cerulean"
game "gta5"
lua54 "yes"

author 'MXC'
description 'BOUNTY'
version '1.0.0'

this_is_a_map 'yes'

data_file 'DLC_ITYP_REQUEST' 'm24_1_int_01_m241_mxc_ytyp.ytyp'

client_script {
    'mxc_entityset_mods.lua',
}